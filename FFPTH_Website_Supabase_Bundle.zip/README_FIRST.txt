FFPTH — Website + Supabase setup bundle

Contents
- index.html: Original FFPTH website file, renamed so static hosting can detect it.
- FFPTH_Supabase_Migration_v2_Reviewed.sql: Reviewed, non-destructive database schema migration for Supabase project THp.

IMPORTANT
1. This bundle does NOT yet connect the website to Supabase. It packages the original website and the database setup script together for convenience.
2. Do not open index.html directly and expect cloud saving to work. A browser page alone cannot provide a hosted database.
3. Do not run the SQL until you have checked that the Supabase dashboard is for project THp and reviewed the SQL.
4. The original HTML uses a legacy client-side login/data mechanism. It must be replaced with Supabase Auth and Supabase database calls before persistent saving works.
5. Never put a Supabase service_role/secret key in index.html. Use only a publishable/anon key in the frontend with correct Row Level Security policies.

Suggested next steps
- Review/run the SQL in Supabase SQL Editor only after confirming the target project.
- Then update the website JavaScript to use Supabase Auth and the new tables, test it, and redeploy to Netlify.
