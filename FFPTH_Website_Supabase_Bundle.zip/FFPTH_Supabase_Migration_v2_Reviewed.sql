-- FFPTH Supabase migration v1
-- Safe additive migration: creates isolated ffpth_* objects and does not drop
-- existing tables or delete existing data. Review before running in production.
-- Run once in Supabase Dashboard -> SQL Editor as project owner.
-- This migration does NOT import the legacy HTML seed data and does NOT create
-- or promote an administrator automatically.
-- Run in Supabase Dashboard -> SQL Editor as project owner.
-- IMPORTANT: Do not put service_role / secret keys in the website.

create extension if not exists pgcrypto;

-- Confirm the intended project before running:
-- Project ref: mntxvqzspqcwdaebixwe
-- No service_role / secret key is needed for this SQL migration.

-- 1) Member profiles. Auth passwords remain managed by Supabase Auth.
create table if not exists public.ffpth_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  game_name text,
  country char(2) not null default 'TH',
  ff_uid text,
  avatar_url text,
  role text not null default 'member' check (role in ('member','admin')),
  status text not null default 'pending' check (status in ('pending','approved','suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.ffpth_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.ffpth_profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
      and p.status = 'approved'
  );
$$;

create or replace function public.ffpth_touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists ffpth_profiles_touch on public.ffpth_profiles;
create trigger ffpth_profiles_touch
before update on public.ffpth_profiles
for each row execute function public.ffpth_touch_updated_at();

create or replace function public.ffpth_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.ffpth_profiles (id, username, display_name, game_name, country, ff_uid)
  values (
    new.id,
    nullif(new.raw_user_meta_data->>'username',''),
    nullif(new.raw_user_meta_data->>'display_name',''),
    nullif(new.raw_user_meta_data->>'game_name',''),
    coalesce(nullif(new.raw_user_meta_data->>'country',''), 'TH'),
    nullif(new.raw_user_meta_data->>'ff_uid','')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists ffpth_auth_user_created on auth.users;
create trigger ffpth_auth_user_created
after insert on auth.users
for each row execute function public.ffpth_handle_new_user();

-- 2) Existing FFPTH player leaderboard data.
create table if not exists public.ffpth_players (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  game_name text not null,
  country char(2) not null default 'TH',
  birth_year integer,
  ff_uid text,
  elo_hs integer,
  elo_ep integer,
  elo_ss integer,
  title_hs text,
  title_ep text,
  title_ss text,
  is_banned boolean not null default false,
  ban_until date,
  ban_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists ffpth_players_touch on public.ffpth_players;
create trigger ffpth_players_touch
before update on public.ffpth_players
for each row execute function public.ffpth_touch_updated_at();

-- 3) Match records / Elo history.
create table if not exists public.ffpth_matches (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  player_id uuid not null references public.ffpth_players(id) on delete cascade,
  played_on date not null default current_date,
  event_name text,
  category text not null check (category in ('hs','ep','ss')),
  opponent_name text,
  opponent_elo integer,
  result text check (result in ('W','D','L','N')),
  elo_before integer,
  elo_change integer not null default 0,
  elo_after integer,
  note text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists ffpth_matches_player_date_idx
  on public.ffpth_matches(player_id, played_on desc);

-- 4) Tournaments and registrations.
create table if not exists public.ffpth_tournaments (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  name text not null,
  tournament_date date,
  category text check (category in ('hs','ep','ss') or category is null),
  status text not null default 'upcoming' check (status in ('upcoming','live','done','cancelled')),
  note text,
  capacity integer check (capacity is null or capacity > 0),
  registration_open boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists ffpth_tournaments_touch on public.ffpth_tournaments;
create trigger ffpth_tournaments_touch
before update on public.ffpth_tournaments
for each row execute function public.ffpth_touch_updated_at();

create table if not exists public.ffpth_registrations (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.ffpth_tournaments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  game_name text not null,
  country char(2) not null default 'TH',
  ff_uid text,
  created_at timestamptz not null default now(),
  unique (tournament_id, user_id)
);

-- 5) RLS: public can read leaderboard / match history / tournaments.
alter table public.ffpth_profiles enable row level security;
alter table public.ffpth_players enable row level security;
alter table public.ffpth_matches enable row level security;
alter table public.ffpth_tournaments enable row level security;
alter table public.ffpth_registrations enable row level security;

drop policy if exists ffpth_profiles_read_self on public.ffpth_profiles;
create policy ffpth_profiles_read_self on public.ffpth_profiles
for select to authenticated using (id = auth.uid() or public.ffpth_is_admin());

drop policy if exists ffpth_profiles_admin_read on public.ffpth_profiles;
create policy ffpth_profiles_admin_read on public.ffpth_profiles
for select to authenticated using (public.ffpth_is_admin());

drop policy if exists ffpth_profiles_update_self_fields on public.ffpth_profiles;
-- Column-level grants below restrict self-service updates to safe profile fields.
create policy ffpth_profiles_update_self_fields on public.ffpth_profiles
for update to authenticated
using (id = auth.uid())
with check (id = auth.uid());

drop policy if exists ffpth_profiles_admin_update on public.ffpth_profiles;
create policy ffpth_profiles_admin_update on public.ffpth_profiles
for update to authenticated
using (public.ffpth_is_admin())
with check (public.ffpth_is_admin());

drop policy if exists ffpth_players_public_read on public.ffpth_players;
create policy ffpth_players_public_read on public.ffpth_players
for select to anon, authenticated using (true);
drop policy if exists ffpth_players_admin_write on public.ffpth_players;
create policy ffpth_players_admin_write on public.ffpth_players
for all to authenticated using (public.ffpth_is_admin()) with check (public.ffpth_is_admin());

drop policy if exists ffpth_matches_public_read on public.ffpth_matches;
create policy ffpth_matches_public_read on public.ffpth_matches
for select to anon, authenticated using (true);
drop policy if exists ffpth_matches_admin_write on public.ffpth_matches;
create policy ffpth_matches_admin_write on public.ffpth_matches
for all to authenticated using (public.ffpth_is_admin()) with check (public.ffpth_is_admin());

drop policy if exists ffpth_tournaments_public_read on public.ffpth_tournaments;
create policy ffpth_tournaments_public_read on public.ffpth_tournaments
for select to anon, authenticated using (true);
drop policy if exists ffpth_tournaments_admin_write on public.ffpth_tournaments;
create policy ffpth_tournaments_admin_write on public.ffpth_tournaments
for all to authenticated using (public.ffpth_is_admin()) with check (public.ffpth_is_admin());

drop policy if exists ffpth_registrations_read on public.ffpth_registrations;
drop policy if exists ffpth_registrations_select_self_or_admin on public.ffpth_registrations;
create policy ffpth_registrations_select_self_or_admin on public.ffpth_registrations
for select to authenticated using (user_id = auth.uid() or public.ffpth_is_admin());
drop policy if exists ffpth_registrations_insert_self on public.ffpth_registrations;
create policy ffpth_registrations_insert_self on public.ffpth_registrations
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists ffpth_registrations_delete_self_or_admin on public.ffpth_registrations;
create policy ffpth_registrations_delete_self_or_admin on public.ffpth_registrations
for delete to authenticated using (user_id = auth.uid() or public.ffpth_is_admin());

-- Prevent members from changing their own role/status.
revoke update on public.ffpth_profiles from anon, authenticated;
grant update (username, display_name, game_name, country, ff_uid, avatar_url)
on public.ffpth_profiles to authenticated;
grant select on public.ffpth_profiles to authenticated;
grant select on public.ffpth_players, public.ffpth_matches, public.ffpth_tournaments,
  public.ffpth_registrations to anon, authenticated;
grant insert, update, delete on public.ffpth_players, public.ffpth_matches,
  public.ffpth_tournaments to authenticated;
grant insert, delete on public.ffpth_registrations to authenticated;

-- 6) Admin-only member approval/suspension. Role is intentionally not editable here.
create or replace function public.ffpth_set_member_status(target_user uuid, new_status text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.ffpth_is_admin() then
    raise exception 'not authorized';
  end if;
  if new_status not in ('pending','approved','suspended') then
    raise exception 'invalid status';
  end if;
  update public.ffpth_profiles set status = new_status where id = target_user;
  if not found then raise exception 'member not found'; end if;
end;
$$;

revoke all on function public.ffpth_set_member_status(uuid,text) from public;
grant execute on function public.ffpth_set_member_status(uuid,text) to authenticated;

-- 7) Transaction-safe tournament signup with capacity and duplicate checks.
create or replace function public.ffpth_register_for_tournament(
  target_tournament uuid,
  entered_game_name text,
  entered_country text default 'TH',
  entered_ff_uid text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  t public.ffpth_tournaments%rowtype;
  new_id uuid;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not exists (
    select 1 from public.ffpth_profiles p
    where p.id = auth.uid() and p.status = 'approved'
  ) then
    raise exception 'membership pending approval';
  end if;
  select * into t from public.ffpth_tournaments
    where id = target_tournament for update;
  if not found then raise exception 'tournament not found'; end if;
  if not t.registration_open or t.status <> 'upcoming' then
    raise exception 'registration closed';
  end if;
  if t.capacity is not null and
     (select count(*) from public.ffpth_registrations where tournament_id = target_tournament) >= t.capacity then
    raise exception 'tournament full';
  end if;
  insert into public.ffpth_registrations
    (tournament_id, user_id, game_name, country, ff_uid)
  values
    (target_tournament, auth.uid(), left(trim(entered_game_name),40),
     coalesce(nullif(entered_country,''),'TH'), nullif(entered_ff_uid,''))
  returning id into new_id;
  return new_id;
end;
$$;

revoke all on function public.ffpth_register_for_tournament(uuid,text,text,text) from public;
grant execute on function public.ffpth_register_for_tournament(uuid,text,text,text) to authenticated;

create or replace function public.ffpth_cancel_registration(target_registration uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  delete from public.ffpth_registrations
  where id = target_registration
    and (user_id = auth.uid() or public.ffpth_is_admin());
  if not found then raise exception 'registration not found or not authorized'; end if;
end;
$$;

revoke all on function public.ffpth_cancel_registration(uuid) from public;
grant execute on function public.ffpth_cancel_registration(uuid) to authenticated;

-- 8) Public-safe profile view: no email, auth identifiers, or role information.
-- Public profile view only exposes approved members. Use security_invoker so
-- underlying RLS remains effective on supported PostgreSQL/Supabase versions.
create or replace view public.ffpth_public_profiles
with (security_invoker = true) as
select id, username, display_name, game_name, country, ff_uid, avatar_url, created_at
from public.ffpth_profiles
where status = 'approved';

grant select on public.ffpth_public_profiles to anon, authenticated;

-- Deliberately do NOT create a public registrations view: registration records
-- can contain player identifiers and should remain visible only to the owner/admin.

-- FIRST ADMIN BOOTSTRAP (run separately, only after the intended admin has signed up):
-- Replace the email below with the exact email of the account you control.
-- Run this statement separately in SQL Editor after the migration succeeds:
--
-- update public.ffpth_profiles p
-- set role = 'admin', status = 'approved'
-- from auth.users u
-- where p.id = u.id
--   and lower(u.email) = lower('YOUR_ADMIN_EMAIL');
--
-- Verify exactly one row was updated before proceeding. Never promote an
-- account based only on a username supplied by a browser.
